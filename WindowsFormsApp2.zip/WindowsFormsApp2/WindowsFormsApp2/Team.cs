﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Team : Form
    {
        Form1 frm1;
        DataTable dtAdd = new DataTable();
        public Team(Form1 _sender)
        {
            InitializeComponent();
            frm1 = _sender;
        }

        private void Team_Load(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string newTeam = tb_addteamname.Text;
            frm1.setNama(newTeam);
            this.Close();
            Form1.form1.left.Rows.Add(newTeam);
            Form1.form1.right.Rows.Add(newTeam);
            //Form1.form1.cb_team1.DataSource = Form1.form1.left;
            //Form1.form1.cb_team2.DataSource = Form1.form1.right;

            Form1.form1.cb_team1.Items.Add(newTeam);
            Form1.form1.cb_team2.Items.Add(newTeam);
           
        }
    }
}
