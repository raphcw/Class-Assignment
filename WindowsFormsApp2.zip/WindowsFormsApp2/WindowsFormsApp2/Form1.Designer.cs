﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            this.dtp_1 = new System.Windows.Forms.DateTimePicker();
            this.cb_team1 = new System.Windows.Forms.ComboBox();
            this.cb_team2 = new System.Windows.Forms.ComboBox();
            this.tb_score1 = new System.Windows.Forms.TextBox();
            this.tb_score2 = new System.Windows.Forms.TextBox();
            this.btn_addmatch = new System.Windows.Forms.Button();
            this.btn_addteam = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_1
            // 
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.Location = new System.Drawing.Point(74, 44);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.RowHeadersWidth = 82;
            this.dgv_1.RowTemplate.Height = 33;
            this.dgv_1.Size = new System.Drawing.Size(1654, 484);
            this.dgv_1.TabIndex = 0;
            // 
            // dtp_1
            // 
            this.dtp_1.Location = new System.Drawing.Point(647, 620);
            this.dtp_1.Name = "dtp_1";
            this.dtp_1.Size = new System.Drawing.Size(401, 31);
            this.dtp_1.TabIndex = 1;
            // 
            // cb_team1
            // 
            this.cb_team1.FormattingEnabled = true;
            this.cb_team1.Location = new System.Drawing.Point(647, 680);
            this.cb_team1.Name = "cb_team1";
            this.cb_team1.Size = new System.Drawing.Size(167, 33);
            this.cb_team1.TabIndex = 2;
            this.cb_team1.SelectedIndexChanged += new System.EventHandler(this.cb_team1_SelectedIndexChanged);
            // 
            // cb_team2
            // 
            this.cb_team2.FormattingEnabled = true;
            this.cb_team2.Items.AddRange(new object[] {
            ""});
            this.cb_team2.Location = new System.Drawing.Point(875, 680);
            this.cb_team2.Name = "cb_team2";
            this.cb_team2.Size = new System.Drawing.Size(173, 33);
            this.cb_team2.TabIndex = 3;
            this.cb_team2.SelectedIndexChanged += new System.EventHandler(this.cb_team2_SelectedIndexChanged);
            // 
            // tb_score1
            // 
            this.tb_score1.Location = new System.Drawing.Point(647, 766);
            this.tb_score1.Name = "tb_score1";
            this.tb_score1.Size = new System.Drawing.Size(167, 31);
            this.tb_score1.TabIndex = 4;
            this.tb_score1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_score1_KeyPress);
            // 
            // tb_score2
            // 
            this.tb_score2.Location = new System.Drawing.Point(875, 766);
            this.tb_score2.Name = "tb_score2";
            this.tb_score2.Size = new System.Drawing.Size(173, 31);
            this.tb_score2.TabIndex = 5;
            this.tb_score2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_score2_KeyPress);
            // 
            // btn_addmatch
            // 
            this.btn_addmatch.Location = new System.Drawing.Point(647, 870);
            this.btn_addmatch.Name = "btn_addmatch";
            this.btn_addmatch.Size = new System.Drawing.Size(167, 45);
            this.btn_addmatch.TabIndex = 6;
            this.btn_addmatch.Text = "Add Match";
            this.btn_addmatch.UseVisualStyleBackColor = true;
            this.btn_addmatch.Click += new System.EventHandler(this.btn_addmatch_Click);
            // 
            // btn_addteam
            // 
            this.btn_addteam.Location = new System.Drawing.Point(858, 870);
            this.btn_addteam.Name = "btn_addteam";
            this.btn_addteam.Size = new System.Drawing.Size(203, 45);
            this.btn_addteam.TabIndex = 7;
            this.btn_addteam.Text = "Add Team";
            this.btn_addteam.UseVisualStyleBackColor = true;
            this.btn_addteam.Click += new System.EventHandler(this.btn_addteam_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(86, 553);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(172, 57);
            this.btn_delete.TabIndex = 8;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(829, 683);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "VS";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1820, 1199);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_addteam);
            this.Controls.Add(this.btn_addmatch);
            this.Controls.Add(this.tb_score2);
            this.Controls.Add(this.tb_score1);
            this.Controls.Add(this.cb_team2);
            this.Controls.Add(this.cb_team1);
            this.Controls.Add(this.dtp_1);
            this.Controls.Add(this.dgv_1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_1;
        private System.Windows.Forms.DateTimePicker dtp_1;
        private System.Windows.Forms.TextBox tb_score1;
        private System.Windows.Forms.TextBox tb_score2;
        private System.Windows.Forms.Button btn_addmatch;
        private System.Windows.Forms.Button btn_addteam;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ComboBox cb_team1;
        public System.Windows.Forms.ComboBox cb_team2;
    }
}

