﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        DataTable team;
        public DataTable left;
        public DataTable right;
        Team frm2;
        public static Form1 form1;
        

        
        public Form1()
        {
            InitializeComponent();
            form1 = this;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            team = new DataTable();
            team.Columns.Add("Date");
            team.Columns.Add("Home Team Name");
            team.Columns.Add("Home Score");
            team.Columns.Add("Away Score");
            team.Columns.Add("Away Team Name");
            dgv_1.DataSource = team;

            left = new DataTable();
            left.Columns.Add("Boston Celtics");
            left.Rows.Add("LA Lakers");
            left.Rows.Add("Phoenix Suns");
            left.Rows.Add("Golden State Warriors");
            left.Rows.Add("Dallas Mavericks");
            left.Rows.Add("Denver Nuggets");
            for (int i = 0; i < left.Rows.Count; i++)
            {
                cb_team1.Items.Add(left.Rows[i][0].ToString());
            }
            //cb_team1.DataSource = left;



            right = new DataTable();
            right.Columns.Add("Boston Celtics");
            right.Rows.Add("LA Lakers");
            right.Rows.Add("Phoenix Suns");
            right.Rows.Add("Golden State Warriors");
            right.Rows.Add("Dallas Mavericks");
            right.Rows.Add("Denver Nuggets");
            for (int i = 0; i < right.Rows.Count; i++)
            {
                cb_team2.Items.Add(right.Rows[i][0].ToString());
            }
            //cb_team2.DataSource = right;

        }

        private void cb_team1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string select = cb_team1.SelectedItem.ToString();
            for (int i = 0; i < right.Rows.Count; i++)
            {
                if (right.Rows[i][0].ToString() == select)
                {
                    right.Rows.Remove(right.Rows[i]);
                }
            }
            cb_team2.Items.Clear();
            for (int i = 0; i < right.Rows.Count; i++)
            {
                cb_team2.Items.Add(right.Rows[i][0]).ToString();

                
            }
        }

        private void cb_team2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string select = cb_team2.SelectedItem.ToString();
            for (int i = 0; i < left.Rows.Count; i++)
            {
                if (left.Rows[i][0].ToString() == select)
                {
                    left.Rows.Remove(left.Rows[i]);
                }
            }
            cb_team1.Items.Clear();
            for (int i = 0; i < left.Rows.Count; i++)
            {
                cb_team1.Items.Add(left.Rows[i][0]).ToString();


            }
        }

        private void tb_score1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            if ((sender as TextBox).TextLength >= 3 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_score2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            if ((sender as TextBox).TextLength >= 3 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void btn_addmatch_Click(object sender, EventArgs e)
        {
            string left = cb_team1.Text;

            team.Rows.Add(dtp_1.Value.ToString(), left, tb_score1.Text ,  cb_team2.SelectedItem, tb_score2.Text );
            dgv_1.DataSource = team;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentrow = dgv_1.CurrentRow;
            dgv_1.Rows.Remove(currentrow);
        }

        public void setNama(string nma)
        {
            left.Rows.Add(nma);
            right.Rows.Add(nma);
        }

        private void btn_addteam_Click(object sender, EventArgs e)
        {
            frm2 = new Team(this);
            frm2.ShowDialog();
        }

        public void Hilang()
        {
            cb_team1.Items.Clear();
            cb_team1.DataSource = left;
            cb_team2.Items.Clear();
            cb_team2.DataSource = right;
        }
        
    }
}
