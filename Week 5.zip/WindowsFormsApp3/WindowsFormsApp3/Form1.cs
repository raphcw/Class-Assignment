﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
      
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("ID Tim");
            dt.Columns.Add("Nama Tim");
            dt.Columns.Add("Nama Stadium");
            dt.Columns.Add("Kapasitas");
            dt.Columns.Add("Kota");
            dt.Columns.Add("Nama Manager");
            dgv_1.DataSource = dt;
            tbox_id.Text = "";
            tbox_id.Enabled = false;
        }

        private void btn_input_Click(object sender, EventArgs e)
        {
            string teamID = tbox_id.Text;
            string teamname = tbox_tim.Text;
            string stadiumName = tbox_stadium.Text;
            string capacity = tbox_kapasitas.Text;
            string cityName = tbox_kota.Text;
            string managerName = tbox_manager.Text;

            bool team = false;
            bool stadium = false;
            bool manager = false;

            if (tbox_tim.Text == "" || tbox_stadium.Text == "" || tbox_kapasitas.Text == "" || tbox_kota.Text =="" || tbox_manager.Text == "")
            {
                MessageBox.Show("Please fill all the fields below!!" , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            foreach (DataRow row in dt.Rows)
            {
                if (row["Nama Tim"].ToString() == teamname)
                {
                    team = true;
                }

                else if (row["Nama Stadium"].ToString() == stadiumName)
                {
                    stadium = true;
                }

                else if (row["Nama Manager"].ToString() == managerName)
                {
                    manager = true;
                }
            }
            
            if (team == true)
            {
                MessageBox.Show("Nama Tim Tidak Boleh Sama", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else if (stadium == true)
            {
                MessageBox.Show("Nama Stadium Tidak Boleh Sama", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else if (manager == true)
            {
                 MessageBox.Show("Nama Manager Tidak Boleh Sama", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

            else
            {
                dt.Rows.Add(teamID, teamname, stadiumName, capacity, cityName, managerName);
            }

            
            tbox_id.Text = "";
            tbox_tim.Text = "";
            tbox_stadium.Text = "";
            tbox_kapasitas.Text = "";
            tbox_kota.Text = "";
            tbox_manager.Text = "";
            
            dgv_1.DataSource = dt;
        }

        private void tbox_tim_TextChanged(object sender, EventArgs e)
        {
            int count = 0;
            string id = "";
            tbox_id.Text = "";

            if (tbox_tim.Text != "")
            {
                id += tbox_tim.Text[0].ToString().ToUpper();
            }

            int angka = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string idTeam = dt.Rows[i]["ID Tim"].ToString();

                if (idTeam[0].ToString() == id)
                {
                    count++;
                }
            }

            if (count <  10)
            {
                angka = count + 1;
                id += "0" + angka.ToString();
            }

            else
            {
                id += (count + 1).ToString();
            }

            if (tbox_tim.Text != "")
            {
                tbox_id.Text = id;
            }
        }


    }
}
