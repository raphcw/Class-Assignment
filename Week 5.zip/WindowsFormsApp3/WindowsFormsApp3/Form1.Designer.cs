﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_idteam = new System.Windows.Forms.Label();
            this.lb_namatim = new System.Windows.Forms.Label();
            this.lb_namastadium = new System.Windows.Forms.Label();
            this.lb_kapasitas = new System.Windows.Forms.Label();
            this.lb_kota = new System.Windows.Forms.Label();
            this.lb_namamanager = new System.Windows.Forms.Label();
            this.tbox_id = new System.Windows.Forms.TextBox();
            this.tbox_tim = new System.Windows.Forms.TextBox();
            this.tbox_stadium = new System.Windows.Forms.TextBox();
            this.tbox_kapasitas = new System.Windows.Forms.TextBox();
            this.tbox_kota = new System.Windows.Forms.TextBox();
            this.tbox_manager = new System.Windows.Forms.TextBox();
            this.btn_input = new System.Windows.Forms.Button();
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_idteam
            // 
            this.lb_idteam.AutoSize = true;
            this.lb_idteam.Location = new System.Drawing.Point(75, 114);
            this.lb_idteam.Name = "lb_idteam";
            this.lb_idteam.Size = new System.Drawing.Size(98, 25);
            this.lb_idteam.TabIndex = 0;
            this.lb_idteam.Text = "ID Team:";
            // 
            // lb_namatim
            // 
            this.lb_namatim.AutoSize = true;
            this.lb_namatim.Location = new System.Drawing.Point(58, 187);
            this.lb_namatim.Name = "lb_namatim";
            this.lb_namatim.Size = new System.Drawing.Size(115, 25);
            this.lb_namatim.TabIndex = 1;
            this.lb_namatim.Text = "Nama Tim:";
            // 
            // lb_namastadium
            // 
            this.lb_namastadium.AutoSize = true;
            this.lb_namastadium.Location = new System.Drawing.Point(18, 260);
            this.lb_namastadium.Name = "lb_namastadium";
            this.lb_namastadium.Size = new System.Drawing.Size(158, 25);
            this.lb_namastadium.TabIndex = 2;
            this.lb_namastadium.Text = "Nama Stadium:";
            // 
            // lb_kapasitas
            // 
            this.lb_kapasitas.AutoSize = true;
            this.lb_kapasitas.Location = new System.Drawing.Point(58, 324);
            this.lb_kapasitas.Name = "lb_kapasitas";
            this.lb_kapasitas.Size = new System.Drawing.Size(113, 25);
            this.lb_kapasitas.TabIndex = 3;
            this.lb_kapasitas.Text = "Kapasitas:";
            // 
            // lb_kota
            // 
            this.lb_kota.AutoSize = true;
            this.lb_kota.Location = new System.Drawing.Point(109, 389);
            this.lb_kota.Name = "lb_kota";
            this.lb_kota.Size = new System.Drawing.Size(62, 25);
            this.lb_kota.TabIndex = 4;
            this.lb_kota.Text = "Kota:";
            this.lb_kota.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lb_namamanager
            // 
            this.lb_namamanager.AutoSize = true;
            this.lb_namamanager.Location = new System.Drawing.Point(11, 454);
            this.lb_namamanager.Name = "lb_namamanager";
            this.lb_namamanager.Size = new System.Drawing.Size(165, 25);
            this.lb_namamanager.TabIndex = 5;
            this.lb_namamanager.Text = "Nama Manager:";
            // 
            // tbox_id
            // 
            this.tbox_id.Location = new System.Drawing.Point(182, 114);
            this.tbox_id.Name = "tbox_id";
            this.tbox_id.Size = new System.Drawing.Size(132, 31);
            this.tbox_id.TabIndex = 6;
            // 
            // tbox_tim
            // 
            this.tbox_tim.Location = new System.Drawing.Point(182, 187);
            this.tbox_tim.Name = "tbox_tim";
            this.tbox_tim.Size = new System.Drawing.Size(132, 31);
            this.tbox_tim.TabIndex = 7;
            this.tbox_tim.TextChanged += new System.EventHandler(this.tbox_tim_TextChanged);
            // 
            // tbox_stadium
            // 
            this.tbox_stadium.Location = new System.Drawing.Point(182, 257);
            this.tbox_stadium.Name = "tbox_stadium";
            this.tbox_stadium.Size = new System.Drawing.Size(132, 31);
            this.tbox_stadium.TabIndex = 8;
            // 
            // tbox_kapasitas
            // 
            this.tbox_kapasitas.Location = new System.Drawing.Point(182, 324);
            this.tbox_kapasitas.Name = "tbox_kapasitas";
            this.tbox_kapasitas.Size = new System.Drawing.Size(132, 31);
            this.tbox_kapasitas.TabIndex = 9;
            // 
            // tbox_kota
            // 
            this.tbox_kota.Location = new System.Drawing.Point(182, 389);
            this.tbox_kota.Name = "tbox_kota";
            this.tbox_kota.Size = new System.Drawing.Size(132, 31);
            this.tbox_kota.TabIndex = 10;
            // 
            // tbox_manager
            // 
            this.tbox_manager.Location = new System.Drawing.Point(182, 448);
            this.tbox_manager.Name = "tbox_manager";
            this.tbox_manager.Size = new System.Drawing.Size(132, 31);
            this.tbox_manager.TabIndex = 11;
            // 
            // btn_input
            // 
            this.btn_input.Location = new System.Drawing.Point(184, 513);
            this.btn_input.Name = "btn_input";
            this.btn_input.Size = new System.Drawing.Size(130, 47);
            this.btn_input.TabIndex = 12;
            this.btn_input.Text = "Input";
            this.btn_input.UseVisualStyleBackColor = true;
            this.btn_input.Click += new System.EventHandler(this.btn_input_Click);
            // 
            // dgv_1
            // 
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.Location = new System.Drawing.Point(21, 598);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.RowHeadersWidth = 82;
            this.dgv_1.RowTemplate.Height = 33;
            this.dgv_1.Size = new System.Drawing.Size(2161, 611);
            this.dgv_1.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2457, 1265);
            this.Controls.Add(this.dgv_1);
            this.Controls.Add(this.btn_input);
            this.Controls.Add(this.tbox_manager);
            this.Controls.Add(this.tbox_kota);
            this.Controls.Add(this.tbox_kapasitas);
            this.Controls.Add(this.tbox_stadium);
            this.Controls.Add(this.tbox_tim);
            this.Controls.Add(this.tbox_id);
            this.Controls.Add(this.lb_namamanager);
            this.Controls.Add(this.lb_kota);
            this.Controls.Add(this.lb_kapasitas);
            this.Controls.Add(this.lb_namastadium);
            this.Controls.Add(this.lb_namatim);
            this.Controls.Add(this.lb_idteam);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_idteam;
        private System.Windows.Forms.Label lb_namatim;
        private System.Windows.Forms.Label lb_namastadium;
        private System.Windows.Forms.Label lb_kapasitas;
        private System.Windows.Forms.Label lb_kota;
        private System.Windows.Forms.Label lb_namamanager;
        private System.Windows.Forms.TextBox tbox_id;
        private System.Windows.Forms.TextBox tbox_tim;
        private System.Windows.Forms.TextBox tbox_stadium;
        private System.Windows.Forms.TextBox tbox_kapasitas;
        private System.Windows.Forms.TextBox tbox_kota;
        private System.Windows.Forms.TextBox tbox_manager;
        private System.Windows.Forms.Button btn_input;
        private System.Windows.Forms.DataGridView dgv_1;
    }
}

